﻿using ExcelDataReader;
using FinalTest.DataAccess;
using FinalTest.Models;
using FinalTest.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using PagedList;
using System.Data;
using System.Linq;
using System.Reflection.Emit;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace FinalTest.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _dbContext;


        public AdminController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        [HttpGet]
        [HttpPost]
        [Authentication]
        public IActionResult Index(string? searchString, int page = 1, int pagesize = 3)
        {
            //ViewBag.Roledata = HttpContext.Session.GetString("Role");
            //if (ViewBag.Roledata == null)
            //{
            //    return RedirectToAction("Index", "Home");
            //}
            ViewData["CurrentFilter"] = searchString;

            var data = (from s in _dbContext.students
                        join sc in _dbContext.studentCourses on s.StudentId equals sc.StudentId into scs
                        from scsresult in scs.DefaultIfEmpty()
                        join c in _dbContext.courses on scsresult.CourseId equals c.CourseId into scsc
                        from courseresult in scsc.DefaultIfEmpty()
                        group new { s, courseresult } by new { s.StudentId, s.Name, s.Email, s.ContactNo, s.RollNo, s.Address, s.State, s.City, s.Zipcode } into grp
                        select new StudentVM
                        {
                            StudentId = grp.Key.StudentId,
                            Name = grp.Key.Name,
                            Email = grp.Key.Email,
                            ContactNo = grp.Key.ContactNo.ToString(),
                            RollNo = grp.Key.RollNo,
                            Address = grp.Key.Address,
                            State = grp.Key.State,
                            City = grp.Key.City,
                            Zipcode = grp.Key.Zipcode.ToString(),
                            CourseTotalPrice = grp.Sum(x => x.courseresult.CoursePrice).ToString(),
                        });

            if (!String.IsNullOrEmpty(searchString))
            {
                data = data.Where(s => s.Name.ToLower().Contains(searchString.ToLower()));
            }

            PagedList<StudentVM> model = new PagedList<StudentVM>(data, page, pagesize);

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> setdata(IFormFile file)
        {
            try
            {
                if (file != null)
                {
                    var supportedTypes = new[] { "xlsx" };
                    var fileExt = System.IO.Path.GetExtension(file.FileName).Substring(1);
                    if (!supportedTypes.Contains(fileExt))
                    {
                        TempData["error"] = "File Extension Is InValid - Only Upload EXCEL File";
                        return RedirectToAction("Index");
                    }

                    var list = new List<Student>();
                    System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
                    using (var stream = file.OpenReadStream())
                    {
                        using (var reader = ExcelReaderFactory.CreateReader(stream))
                        {
                            while (reader.Read()) //Each row of the file
                            {
                                var data = reader.IsDBNull(0) ? string.Empty : reader.GetString(0);

                                if (data != "")
                                {
                                    list.Add(new Student
                                    {
                                        Name = reader.GetValue(0).ToString(),
                                        Email = reader.GetValue(1).ToString(),
                                        ContactNo = Convert.ToDouble(reader.GetValue(2).ToString()),
                                        RollNo = reader.GetValue(3).ToString(),
                                        Address = reader.GetValue(4).ToString(),
                                        City = reader.GetValue(5).ToString(),
                                        State = reader.GetValue(6).ToString(),
                                        Zipcode = Convert.ToInt32(reader.GetValue(7).ToString())
                                    });
                                }
                                else
                                {
                                    continue;
                                }

                            }
                        }

                    }
                    _dbContext.students.AddRange(list);
                    await _dbContext.SaveChangesAsync();
                    TempData["success"] = "File Uploaded Successfully";
                    return RedirectToAction("Index");
                }
                TempData["Error"] = "Please Enter File";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }



        [HttpGet]
        [Authentication]
        public IActionResult Upsert(int? id)
        {
            //ViewBag.Roledata = HttpContext.Session.GetString("Role");
            //if (ViewBag.Roledata == null)
            //{
            //    return RedirectToAction("Index", "Home");
            //}
            if (id == null)
            {
                Student stu = new Student();
                return View(stu);
            }
            var data = _dbContext.students.Find(id);
            return View(data);
        }

        [HttpPost]
        public IActionResult Upsert(int id, Student obj)
        {
            try
            {
                if (id == 0 || id == null)
                {

                    var data = new Student()
                    {
                        Name = obj.Name,
                        RollNo = obj.RollNo,
                        Email = obj.Email,
                        Address = obj.Address,
                        ContactNo = obj.ContactNo,
                        State = obj.State,
                        City = obj.City,
                        Zipcode = obj.Zipcode,
                    };

                    _dbContext.students.Add(data);
                    _dbContext.SaveChanges();
                    TempData["success"] = "Student Added Successfully";
                }
                else
                {
                    var data = new Student()
                    {
                        StudentId = id,
                        Name = obj.Name,
                        RollNo = obj.RollNo,
                        Email = obj.Email,
                        Address = obj.Address,
                        ContactNo = obj.ContactNo,
                        State = obj.State,
                        City = obj.City,
                        Zipcode = obj.Zipcode,
                    };

                    _dbContext.students.Update(data);
                    _dbContext.SaveChanges();
                    TempData["success"] = "Student Updated Successfully";
                }

                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        [HttpPost]
        public IActionResult DeleteStudent(int Id)
        {
            var DelStu = _dbContext.students.Find(Id);
            if (DelStu == null)
            {
                TempData["error"] = "Student Delete not Successfully";
                return RedirectToAction("Index", "Admin");
            }

            var SC = _dbContext.studentCourses.Where(x => x.StudentId == Id).ToList();
            if (SC.Count != 0)
            {
                TempData["error"] = "Please Delete Assign Courses first";
                return Json(new { error = true, message = "" });
            }
            _dbContext.students.Remove(DelStu);
            _dbContext.SaveChanges();
            TempData["success"] = "Student Delete Successfully";
            return Json(new { success = true, message = "" });
        }



        [HttpGet]
        [Authentication]
        public IActionResult AddCourse()
        {          
            return View();
        }

        [HttpPost]
        public IActionResult AddCourse(int id, Course obj)
        {
            if (id != 0)
            {
                if (obj != null)
                {
                    var StuCou = _dbContext.studentCourses.Where(x => x.StudentId == id).ToList();  //get list of course id that asign to student

                    foreach (var value in StuCou)
                    {
                        var Cou = _dbContext.courses.Where(x => x.CourseId == value.CourseId);  // get course detail by the course id

                        foreach (var value1 in Cou)
                        {
                            if (value1.CourseName == obj.CourseName)                            //Check Course name exist or not
                            {
                                TempData["error"] = "Course Already Exist";
                                return View();
                            }
                        }
                    }

                    Course data = new Course()
                    {
                        CourseName = obj.CourseName,
                        CoursePrice = obj.CoursePrice
                    };
                    _dbContext.Add(data);
                    _dbContext.SaveChanges();
                    StudentCourses data1 = new StudentCourses()
                    {
                        StudentId = id,
                        CourseId = data.CourseId,
                    };
                    _dbContext.Add(data1);
                    _dbContext.SaveChanges();
                    TempData["success"] = "Course Added Successfully";
                    return RedirectToAction("Index", "Admin");
                }
            }
            return View();
        }


        [HttpGet]
        [Authentication]
        public IActionResult ViewCourse(int id)
        {
            if (id != 0)
            {
                var data = _dbContext.studentCourses.Where(x => x.StudentId == id).ToList();
                List<List<Course>> data1 = new List<List<Course>>();
                foreach (var course in data)
                {
                    data1.Add(_dbContext.courses.Where(x => x.CourseId == course.CourseId).ToList());
                }
                return View(data1);
            }
            return View();
        }


        [HttpPost]
        [Authentication]
        public IActionResult DeleteCourse(int Id)
        {           
            var DelCou = _dbContext.courses.Find(Id);
            if (DelCou == null)
            {
                TempData["error"] = "Course Delete not Successfully";
                return RedirectToAction("Cource", "Admin");
            }
            //delete from the bridge table

            var data = _dbContext.studentCourses.Where(_x => _x.CourseId == Id).FirstOrDefault();
            _dbContext.studentCourses.Remove(data);
            _dbContext.SaveChanges();

            //delete for the courses

            _dbContext.courses.Remove(DelCou);
            _dbContext.SaveChanges();

            TempData["success"] = "Course Delete Successfully";
            return RedirectToAction("Index", "Admin");
        }

        [HttpGet]
        [Authentication]
        public IActionResult EditCourse(int id)
        {
            var data = _dbContext.courses.Find(id);
            return View(data);
        }

        [HttpPost]
        [Authentication]
        public async Task<IActionResult> EditCourse(int id, Course obj)
        {          
            if (ModelState.IsValid)
            {
                var StuCou = _dbContext.studentCourses.Where(x => x.CourseId == id).ToList();

                foreach (var value in StuCou)
                {
                    var Cou = _dbContext.studentCourses.Where(x => x.StudentId == value.StudentId).ToList();

                    foreach (var value1 in Cou)
                    {
                        var Cou1 = _dbContext.courses.Where(x => x.CourseId == value1.CourseId).ToList();

                        foreach (var value2 in Cou1)
                        {
                            if (value2.CourseName == obj.CourseName)
                            {
                                TempData["error"] = "Course Already Exist";
                                return View();
                            }
                        }
                    }

                }

                var data = _dbContext.courses.Find(id);
                 
                data.CourseName = obj.CourseName;
                data.CoursePrice = obj.CoursePrice;
                
                _dbContext.courses.Update(data);
                _dbContext.SaveChanges();
                TempData["success"] = "Course Updated Successfully";
                return RedirectToAction("index", "Admin");
            }

            return View();
        }
    }
}
