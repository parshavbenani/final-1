﻿using ExcelDataReader;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using MVCExcel.Models;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

namespace MVCExcel.Controllers
{
    public class ExcelController : Controller
    {
        static dynamic Tdata;
        static int OS;
        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Index(IFormFile file)
        {
            List<Inventory> inventory = new List<Inventory>();

            List<InventoryVM> inventoryVMs = new List<InventoryVM>();


            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {

                    while (reader.Read()) //Each row of the file
                    {
                        inventory.Add(new Inventory
                        {
                            ProductCode = reader.GetValue(0).ToString(),
                            EventType = int.Parse(reader.GetValue(1).ToString()),
                            Quantity = int.Parse(reader.GetValue(2).ToString()),
                            Price = double.Parse(reader.GetValue(3).ToString()),
                            Date = DateTime.Parse(reader.GetValue(4).ToString())
                        });

                    }
                }

            }

            var month = inventory.GroupBy(x => x.Date.Month).ToList();
            foreach (var item in month)
            {

                int openingstoke = 0;
                

                var product = item.GroupBy(x => x.ProductCode).ToList();
                foreach (var data in product)
                {
                    var date = DateTime.Now;
                    int totalpurchaseqty = 0;
                    double totalpur_Amt = 0;
                    int totalsaleqty = 0;
                    double totalsale_amt = 0;
                    double sale_amt = 0;
                    double profitloss = 0;
                    double Pamount = 0;
                    double Samount = 0;
                    double saletotal = 0;
                    int closeing_stoke = 0;                   
                    var Pcode = "";

                
                    foreach (var type in data)
                    {
                        date = type.Date;
                        Pcode = type.ProductCode;                       

                        if (type.EventType == 1)
                        {
                            totalpurchaseqty += type.Quantity;
                            Pamount = type.Price;
                            totalpur_Amt = totalpurchaseqty * Pamount;                           
                        }
                        else
                        {
                            totalsaleqty = type.Quantity;
                            Samount = type.Price;
                            totalsale_amt = totalsaleqty * Samount;
                            
                        }                      
                       
                        profitloss = (totalsaleqty * Samount) - (totalsaleqty * Pamount);
                        //   closeing_stoke = (totalpurchaseqty + openingstoke )- totalsaleqty;
                        //openingstoke = closeing_stoke;

                    }

                   var data1 =  inventoryVMs.LastOrDefault(x=> x.ProductCode == Pcode.ToString());

                    if(data1 != null)
                    {       
                        inventoryVMs.Add(new InventoryVM
                        {
                            Date = date.ToShortDateString(),
                            ProductCode = Pcode,
                            PurchaseQty = totalpurchaseqty.ToString(),
                            Pur_Amt = Pamount,
                            Total_Pur_Amt = totalpur_Amt.ToString(),
                            TotalSaleQty = totalsaleqty.ToString(),
                            Sale_Amt = Samount.ToString(),
                            TotalSale_Amt = totalsale_amt.ToString(),
                            profitloss = profitloss.ToString(),
                            OpeningStoke = data1.Closingstoke,                           
                            Closingstoke = (Convert.ToInt32(data1.Closingstoke) + totalpurchaseqty - totalsaleqty).ToString(),
                        });

                       

                    }
                    else
                    {
                        inventoryVMs.Add(new InventoryVM
                        {
                            Date = date.ToShortDateString(),
                            ProductCode = Pcode,
                            PurchaseQty = totalpurchaseqty.ToString(),
                            Pur_Amt = Pamount,
                            Total_Pur_Amt = totalpur_Amt.ToString(),
                            TotalSaleQty = totalsaleqty.ToString(),
                            Sale_Amt = Samount.ToString(),
                            TotalSale_Amt = totalsale_amt.ToString(),
                            profitloss = profitloss.ToString(),
                            Closingstoke = (totalpurchaseqty - totalsaleqty).ToString(),
                            OpeningStoke = "0",
                        });
                    }
                    
                }


            }
            Tdata = inventoryVMs.ToList();

            return RedirectToAction("ViewPage");
        }
        public IActionResult ViewPage()
        {

            return View(Tdata);
        }

    }
}
