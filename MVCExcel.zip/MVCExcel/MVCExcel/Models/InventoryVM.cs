﻿namespace MVCExcel.Models
{
    public class InventoryVM
    {
        public string Date { get; set; }
        public string ProductCode { get; set; }
        public string OpeningStoke { get; set; }
        public string PurchaseQty { get; set; }
        public double Pur_Amt { get; set; }
        public string Total_Pur_Amt { get; set; }
        public string TotalSaleQty { get; set; }
        public string Sale_Amt { get; set; }
        public string TotalSale_Amt { get; set; }
        public string profitloss { get; set; }
        public string Closingstoke { get; set; }
    }
}
