﻿using FDemoAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Reflection;

namespace FDemoAPI.Web.Controllers
{
    public class StudentController : Controller
    {
        public async Task<IActionResult> Index()
        {
            string apiUrl = "https://localhost:44396/";

            List<User> students = new List<User>();
            using (var client = new HttpClient())
            {
                //passing Services base url
                client.BaseAddress = new Uri(apiUrl);
                client.DefaultRequestHeaders.Clear();

                //define data format
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                //sending req. to find web api REST service resource GetAllEmployees using HttpClient
                HttpResponseMessage message = await client.GetAsync("api/Student/GetAll");

                //Checking the response is successful or not which is sent using HttpClient
                if(message.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var EmpResponse = message.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Employee list
                    students = JsonConvert.DeserializeObject<List<User>>(EmpResponse);
                }
                //returning the employee list to view
                return View(students);
            }
         
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(User obj)
        {

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44396/");
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Clear();

            HttpResponseMessage response = await client.PostAsJsonAsync("api/Student/Create", obj);

            if (response.IsSuccessStatusCode == true)
            {
                return RedirectToAction("Index", "Student");
            }

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {          
            string apiurl = "https://localhost:44396/";
            var data = new User();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiurl);
                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Accept.Clear();

                HttpResponseMessage message = await client.GetAsync("api/Student/Get?id="+id);

                if (message.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var EmpResponse = message.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Employee list
                    data = JsonConvert.DeserializeObject<User>(EmpResponse);
                }
                //returning the employee list to view
                return View(data);

            }
             
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id,User obj)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44396/");
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Clear();

            HttpResponseMessage response = await client.PutAsJsonAsync("api/Student/Update?id=" + id,obj);
            if (response.IsSuccessStatusCode == true)
            {
                return RedirectToAction("Index","Student");
            }
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            string apiurl = "https://localhost:44396/";
            var data = new User();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiurl);
                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Accept.Clear();

                HttpResponseMessage message = await client.GetAsync("api/Student/Get?id=" + id);

                if (message.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var EmpResponse = message.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Employee list
                    data = JsonConvert.DeserializeObject<User>(EmpResponse);
                }
                //returning the employee list to view
                return View(data);

            }
        }

        [HttpPost]
        [ActionName("Delete")]
        public async Task<IActionResult> DeletePost(int id)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44396/");
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Clear();

            HttpResponseMessage response = await client.DeleteAsync("api/Student/Delete?id=" + id);
            if (response.IsSuccessStatusCode == true)
            {
                return RedirectToAction("Index", "Student");
            }
            return View();         
        }

        



    }
}
