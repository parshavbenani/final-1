﻿using FDemoAPI.Data;
using FDemoAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FDemoAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;

        public StudentController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet]
        [Route("GetAll")]
        public IActionResult GetUsers()
        {
            var data = _dbContext.users.ToList();
            return Ok(data);
        }

        [HttpGet]
        [Route("Get")]
        public IActionResult GetUser(int id)
        {
            var data = _dbContext.users.Find(id);
            return Ok(data);
        }


        [HttpPost]
        [Route("Create")]
        public IActionResult CreateUser(StudentVM obj)
        {
            if(ModelState.IsValid)
            {
                var data = new User()
                {
                    FirstName = obj.FirstName,
                    Lastname = obj.Lastname,
                    UserName = obj.UserName,
                    Password = obj.Password
                };

                _dbContext.users.Add(data);
                _dbContext.SaveChanges();
                return Ok("User Created Successfully");
            }
            return BadRequest();
        }

        [HttpPut]
        [Route("Update")]
        public IActionResult UpdateUser(int id,StudentVM obj)
        {
            if(ModelState.IsValid)
            {
                var data = _dbContext.users.Find(id);

                if(data == null)
                {
                    return Ok("User Not Found");
                }
             
                data.FirstName = obj.FirstName;
                data.Lastname = obj.Lastname;
                data.UserName = obj.UserName;
                data.Password= obj.Password;
             
                _dbContext.users.Update(data);
                _dbContext.SaveChanges();
                return Ok("User Updated Successfully");

            }

            return BadRequest();
        }

        [HttpDelete]
        [Route("Delete")]
        public IActionResult DeleteUser(int id)
        {
            if (ModelState.IsValid)
            {
                var data = _dbContext.users.Find(id);

                if (data == null)
                {
                    return Ok("User Not Found");
                }
              
                _dbContext.users.Remove(data);
                _dbContext.SaveChanges();
                return Ok("User Deleted Successfully");

            }

            return BadRequest();
        }

    }
}
