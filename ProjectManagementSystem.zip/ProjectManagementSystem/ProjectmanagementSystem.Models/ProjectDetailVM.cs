﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectmanagementSystem.Models
{
    public class ProjectDetailVM
    {
        public string ProjectName { get; set; }
        public string ProjectDetail { get; set; }
        public DateTime DeadlineDate { get; set; }
        public List<string> EmployeeName { get; set; }
        public string ProjectManagerName { get; set; }
    }
}
