﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectmanagementSystem.Models
{
    public class ProjectEmployee
    {
        [Key]
        public int PEId { get; set; }
        public string EmployeeId { get; set; }
        public int ProjectId { get; set; }
    }
}
