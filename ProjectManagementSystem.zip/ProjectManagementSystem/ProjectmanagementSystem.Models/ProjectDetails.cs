﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectmanagementSystem.Models
{
    public class ProjectDetails
    {
        [Key]
        public int PId { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDetail { get; set; }
        public DateTime DeadlineDate { get; set; }
        public string ProjectManagerName { get; set; }
    }
}
